'use strict';

 /**
  * This sample demonstrates an implementation of the Lex Code Hook Interface
  * in order to serve a sample bot which manages orders for flowers.
  * Bot, Intent, and Slot models which are compatible with this sample can be found in the Lex Console
  * as part of the 'OrderFlowers' template.
  *
  * For instructions on how to set up and test this bot, as well as additional samples,
  *  visit the Lex Getting Started documentation.
  */


 // --------------- Helpers to build responses which match the structure of the necessary dialog actions -----------------------

function elicitSlot(sessionAttributes, intentName, slots, slotToElicit, message) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'ElicitSlot',
            intentName,
            slots,
            slotToElicit,
            message,
        },
    };
}

function close(sessionAttributes, fulfillmentState, message) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'Close',
            fulfillmentState,
            message,
        },
    };
}

function delegate(sessionAttributes, slots) {
    return {
        sessionAttributes,
        dialogAction: {
            type: 'Delegate',
            slots,
        },
    };
}

// ---------------- Helper Functions --------------------------------------------------

function parseLocalDate(date) {
    /**
     * Construct a date object in the local timezone by parsing the input date string, assuming a YYYY-MM-DD format.
     * Note that the Date(dateString) constructor is explicitly avoided as it may implicitly assume a UTC timezone.
     */
    const dateComponents = date.split(/\-/);
    return new Date(dateComponents[0], dateComponents[1] - 1, dateComponents[2]);
}

function isValidDate(date) {
    try {
        return !(isNaN(parseLocalDate(date).getTime()));
    } catch (err) {
        return false;
    }
}

function buildValidationResult(isValid, violatedSlot, messageContent) {
    if (messageContent === null) {
        return {
            isValid,
            violatedSlot,
        };
    }
    return {
        isValid,
        violatedSlot,
        message: { contentType: 'PlainText', content: messageContent },
    };
}

//function validateOrderFlowers(flowerType, date, time) {
//    const flowerTypes = ['lilies', 'roses', 'tulips'];
//    if (flowerType && flowerTypes.indexOf(flowerType.toLowerCase()) === -1) {
//        return buildValidationResult(false, 'FlowerType', `We do not have ${flowerType}, would you like a different type of flower?  Our most popular flowers are roses`);
//    }
//    if (date) {
//        if (!isValidDate(date)) {
//            return buildValidationResult(false, 'PickupDate', 'I did not understand that, what date would you like to pick the flowers up?');
//        }
//        if (parseLocalDate(date) < new Date()) {
//            return buildValidationResult(false, 'PickupDate', 'You can pick up the flowers from tomorrow onwards.  What day would you like to pick them up?');
//        }
//    }
//    if (time) {
//        if (time.length !== 5) {
//            // Not a valid time; use a prompt defined on the build-time model.
//            return buildValidationResult(false, 'PickupTime', null);
//        }
//        const hour = parseInt(time.substring(0, 2), 10);
//        const minute = parseInt(time.substring(3), 10);
//        if (isNaN(hour) || isNaN(minute)) {
//            // Not a valid time; use a prompt defined on the build-time model.
//            return buildValidationResult(false, 'PickupTime', null);
//        }
//        if (hour < 10 || hour > 16) {
//            // Outside of business hours
//            return buildValidationResult(false, 'PickupTime', 'Our business hours are from ten a m. to five p m. Can you specify a time during this range?');
//        }
//    }
//    return buildValidationResult(true, null, null);
//}

 // --------------- Functions that control the bot's behavior -----------------------

function VRRequestInformation(intentRequest, callback, theintentname) {
    var Modeltype = "test";
    var command = "";
    var commandtype = "";

    switch(theintentname) {
        case "shownextmodel":
            Modeltype = intentRequest.currentIntent.slots.ModelType;
            command = "command:show:" + Modeltype;
            commandtype = "show";    
        break;
        case "tellmeaboutmodel":
            Modeltype = intentRequest.currentIntent.slots.TheModelName;
            command = "command:tellmeaboutmodel:" + Modeltype;
            commandtype = "retrieve information on";
        break;
        case "restarttheapp":
            Modeltype = intentRequest.currentIntent.slots.ApplicationName;
            command = "command:restart:" + Modeltype;
            commandtype = "restarted application for";
        break;
        case "RotateModel":
          Modeltype = intentRequest.currentIntent.slots.TheModel;
          var degrees = intentRequest.currentIntent.slots.Degrees;
          var direction = intentRequest.currentIntent.slots.Direction;
          command = "command:rotate:" + Modeltype + ":" + degrees + ":" + direction;
          commandtype = "rotating";
        break;
        case "startanimation":
           Modeltype = intentRequest.currentIntent.slots.AnimateModel;
           command = "command:startanimation:" + Modeltype;
           commandtype = "animation";
        break;
    }

    const source = intentRequest.invocationSource;
    const outputSessionAttributes = intentRequest.sessionAttributes || {};
    
    var socket = require('socket.io-client')('wss://bobcatdino.azurewebsites.net/');
            
    socket.on('connect', function(){
        socket.on('login', function(data){
                socket.emit('new message', command); //send location as a message
         });

        socket.on('got message', function() {
                socket.disconnect();
         });
        socket.emit('add user', 'lex');
     });
    
    if (source === 'DialogCodeHook') {
        // Perform basic validation on the supplied input slots.  Use the elicitSlot dialog action to re-prompt for the first violation detected.
        //const slots = intentRequest.currentIntent.slots;
        //const validationResult = validateOrderFlowers(flowerType, date, time);
        //if (!validationResult.isValid) {
        //    slots[`${validationResult.violatedSlot}`] = null;
        //    callback(elicitSlot(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, validationResult.violatedSlot, validationResult.message));
        //    return;
        //}

        // Pass the price of the flowers back through session attributes to be used in various prompts defined on the bot model.
        //const outputSessionAttributes = intentRequest.sessionAttributes || {};
        //if (flowerType) {
        //    outputSessionAttributes.Price = flowerType.length * 5; // Elegant pricing model
        //}
        callback(delegate(outputSessionAttributes, intentRequest.currentIntent.slots));
        return;
    }

    // Order the flowers, and rely on the goodbye message of the bot to define the message to the end user.  In a real bot, this would likely involve a call to a backend service.
    callback(close(outputSessionAttributes, 'Fulfilled', { contentType: 'PlainText',content: `The "${commandtype} ${Modeltype}" command has been sent to the VR device.`}));
}

function VRorder(intentRequest, callback) {
    const Modeltype = intentRequest.currentIntent.slots.ModelType;
    //const date = intentRequest.currentIntent.slots.PickupDate;
   // const time = intentRequest.currentIntent.slots.PickupTime;
    const source = intentRequest.invocationSource;
    const outputSessionAttributes = intentRequest.sessionAttributes || {};
    
    var command = "command:show:" + Modeltype;
    
    var socket = require('socket.io-client')('wss://bobcatdino.azurewebsites.net/');
            
    socket.on('connect', function(){
        socket.on('login', function(data){
                socket.emit('new message', command); //send location as a message
         });

        socket.on('got message', function() {
                socket.disconnect();
         });
        socket.emit('add user', 'alexa'); //login as "Alexa`"
     });
    
    if (source === 'DialogCodeHook') {
        // Perform basic validation on the supplied input slots.  Use the elicitSlot dialog action to re-prompt for the first violation detected.
        //const slots = intentRequest.currentIntent.slots;
        //const validationResult = validateOrderFlowers(flowerType, date, time);
        //if (!validationResult.isValid) {
        //    slots[`${validationResult.violatedSlot}`] = null;
        //    callback(elicitSlot(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, validationResult.violatedSlot, validationResult.message));
        //    return;
        //}

        // Pass the price of the flowers back through session attributes to be used in various prompts defined on the bot model.
        //const outputSessionAttributes = intentRequest.sessionAttributes || {};
        //if (flowerType) {
        //    outputSessionAttributes.Price = flowerType.length * 5; // Elegant pricing model
        //}
        callback(delegate(outputSessionAttributes, intentRequest.currentIntent.slots));
        return;
    }

    // Order the flowers, and rely on the goodbye message of the bot to define the message to the end user.  In a real bot, this would likely involve a call to a backend service.
    callback(close(outputSessionAttributes, 'Fulfilled', { contentType: 'PlainText',content: `The "show ${Modeltype} command" has been sent to the VR device.`}));
}

 // --------------- Intents ----------------------- 

/**
 * Called when the user specifies an intent for this skill.
 */
function dispatch(intentRequest, callback) {
    console.log(`dispatch userId=${intentRequest.userId}, intentName=${intentRequest.currentIntent.name}`);

    const intentName = intentRequest.currentIntent.name;
    
    return new VRRequestInformation(intentRequest, callback, intentName);
    
    // TAKE OUT REMAINING
    
    // Dispatch to your skill's intent handlers
//    if (intentName === 'shownextmodel') {
//        return new VRorder(intentRequest, callback);
//    }
    
//    if (intentName === 'tellmeaboutmodel') {
//        return new VRRequestInformation(intentRequest, callback, intentName);
//    }
    
//    if (intentName === "restarttheapp")
//    {
//        return new VRRequestInformation(intentRequest, callback, intentName);
//    }
    
//    if (intentName === "RotateModel")
//    {
//        return new VRRequestInformation(intentRequest, callback, intentName);
//    }
    
//    if (intentName === "startanimation")
//    {
//         return new VRRequestInformation(intentRequest, callback, intentName);
//    }
    
//    if (intentName === "stopanimation")
//    {
//        return new VRRequestInformation(intentRequest, callback, intentName);
//  }
    
    // TODO: Place in remaining intents
    //restarttheapp
    //RotateModel
    //startanimation
    //stopanimation
    
    // maybe not be necessary
    //throw new Error(`Intent with name ${intentName} not supported`);
}

// --------------- Main handler -----------------------

// Route the incoming request based on intent.
// The JSON body of the request is provided in the event slot.
exports.handler = (event, context, callback) => {
    try {
        // By default, treat the user request as coming from the America/New_York time zone.
        process.env.TZ = 'America/New_York';
        console.log(`event.bot.name=${event.bot.name}`);

        /*
         * Uncomment this if statement and populate with your Lex bot name and / or version as
         * a sanity check to prevent invoking this Lambda function from an undesired Lex bot or
         * bot version.
         */
        
      /*  if (event.bot.name !== 'shownextmodel' || event.bot.name !== 'tellmeaboutmodel' || event.bot.name !== 'RotateModel' || event.bot.name !== 'startanimation') {
             callback('Invalid Bot Name');
        }*/
       
    dispatch(event, (response) => callback(null, response));
    } catch (err) {
        callback(err);
    }
};